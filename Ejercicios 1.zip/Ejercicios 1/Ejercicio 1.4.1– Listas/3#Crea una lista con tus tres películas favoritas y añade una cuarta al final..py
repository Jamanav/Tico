peliculas = ["El rey león", "Ratatouille", "Inside Out2 "]
peliculas.append("Avatar")  # Añade una cuarta película
print(peliculas)
