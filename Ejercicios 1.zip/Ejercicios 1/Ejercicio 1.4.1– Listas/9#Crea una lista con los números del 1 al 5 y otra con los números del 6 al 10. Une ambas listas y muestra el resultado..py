# Ejercicio 9
numeros1 = list(range(1, 6))  # Números del 1 al 5
numeros2 = list(range(6, 11))  # Números del 6 al 10
numeros_unidos = numeros1 + numeros2  # Une ambas listas
print(numeros_unidos)
