# Ejercicio 6
animales = ["gato", "perro", "loro"]
animales.insert(1, "tortuga")  # Inserta "tortuga" en la segunda posición
print(animales)
