# Ejercicio 10
lista = [1, 2, 3, 2, 2, 3, 4, 5]
lista = [num for num in lista if num != 2]  # Elimina todos los números 2
print(lista)
