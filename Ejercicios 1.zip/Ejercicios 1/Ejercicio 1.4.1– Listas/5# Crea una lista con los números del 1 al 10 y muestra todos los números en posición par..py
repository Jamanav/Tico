# Ejercicio 5
numeros = list(range(1, 11))  # Crea una lista con los números del 1 al 10
numeros_pares = [num for num in numeros if num % 2 == 0]  # Filtra los números en posición par
print(numeros_pares)
