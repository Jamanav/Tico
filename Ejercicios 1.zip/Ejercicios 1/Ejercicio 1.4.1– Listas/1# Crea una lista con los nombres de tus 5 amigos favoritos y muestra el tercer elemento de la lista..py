amigos = ["Alice", "Bob", "Charlie", "David", "Eva"]
print(amigos[3])  # Muestra el cuarto nombre
