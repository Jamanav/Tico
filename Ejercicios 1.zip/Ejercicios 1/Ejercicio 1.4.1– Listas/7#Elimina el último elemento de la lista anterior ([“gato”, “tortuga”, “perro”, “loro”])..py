# Ejercicio 7
animales = ["gato", "tortuga", "perro", "loro"]
animales.pop("loro")  # Elimina el último elemento
print(animales)
