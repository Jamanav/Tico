# Ejercicio: Muestra la lista invertida
letras = ["a", "b", "c", "d", "e"]
letras_invertidas = letras[:-1]  # Invierte la lista
print(letras_invertidas)
