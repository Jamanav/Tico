numeros = [10, 20, 30, 40]
resultado = sum(numeros)
print(resultado)  # Muestra la suma de todos los numeros indicados anteriormente
