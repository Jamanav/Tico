# Ejercicio 8
nombres = ["Juan", "Ana", "Luis", "Sofia", "Pedro"]
contador = sum(1 for nombre in nombres if len(nombre) > 4)  # Cuenta los nombres mayores a 4 caracteres
print(contador)
