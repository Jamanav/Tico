# Ejercicio 5: Comprobar si "verde" está en el diccionario
colores = {
    "rojo": "red",
    "azul": "blue",
    "verde": "green",
    "amarillo": "yellow",
    "negro": "black",
    "blanco": "white",
    "morado": "purple",
    "naranja": "orange",
    "gris": "gray",
    "rosa": "pink"
}

existe_verde = "verde" in colores
print(f"¿Está 'verde' en el diccionario? {existe_verde}")
