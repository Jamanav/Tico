# Ejercicio 6: Contar colores en inglés con más de 5 caracteres
colores = {
    "rojo": "red",
    "azul": "blue",
    "verde": "green",
    "amarillo": "yellow",
    "negro": "black",
    "blanco": "white",
    "morado": "purple",
    "naranja": "orange",
    "gris": "gray",
    "rosa": "pink"
}

count = sum(1 for color in colores.values() if len(color) > 5)
print(f"Número de colores en inglés con más de 5 caracteres: {count}")
