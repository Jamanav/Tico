# Ejercicio 3: Añadir la traducción de "celeste"
colores = {
    "rojo": "red",
    "azul": "blue",
    "verde": "green",
    "amarillo": "yellow",
    "negro": "black",
    "blanco": "white",
    "morado": "purple",
    "naranja": "orange",
    "gris": "gray",
    "rosa": "pink"
}

colores["celeste"] = "light blue"  # Añadir la traducción
print(colores)
