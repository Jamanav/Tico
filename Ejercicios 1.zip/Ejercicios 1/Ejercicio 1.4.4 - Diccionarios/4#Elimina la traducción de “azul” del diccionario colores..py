# Ejercicio 4: Eliminar la traducción de "azul"
colores = {
    "rojo": "red",
    "azul": "blue",
    "verde": "green",
    "amarillo": "yellow",
    "negro": "black",
    "blanco": "white",
    "morado": "purple",
    "naranja": "orange",
    "gris": "gray",
    "rosa": "pink"
}

colores.pop("azul", None)  # Eliminar "azul" si existe
print(colores)
