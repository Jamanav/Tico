# Ejercicio 2: Mostrar la traducción de "verde"
colores = {
    "rojo": "red",
    "azul": "blue",
    "verde": "green",
    "amarillo": "yellow",
    "negro": "black",
    "blanco": "white",
    "morado": "purple",
    "naranja": "orange",
    "gris": "gray",
    "rosa": "pink"
}

print(f"La traducción de 'verde' es: {colores['verde']}")
