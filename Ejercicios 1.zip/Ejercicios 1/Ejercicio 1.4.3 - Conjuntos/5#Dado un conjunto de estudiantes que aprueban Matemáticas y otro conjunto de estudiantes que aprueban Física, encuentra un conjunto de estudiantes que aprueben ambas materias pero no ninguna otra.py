# Ejercicio 5: Estudiantes que aprueban ambas materias
matematicas = {"Juan", "Ana", "Luis", "Sofia"}
fisica = {"Luis", "Carlos", "Ana", "Javier"}

# Estudiantes que aprueban ambas materias
aprobados_ambas = matematicas.intersection(fisica)
print(f"Estudiantes que aprueban ambas materias: {aprobados_ambas}")
