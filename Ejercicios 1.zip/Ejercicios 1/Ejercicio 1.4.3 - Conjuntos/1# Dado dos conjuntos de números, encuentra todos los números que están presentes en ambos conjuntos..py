# Ejercicio 1: Intersección de dos conjuntos
conjunto1 = {1, 2, 3, 4, 5}
conjunto2 = {4, 5, 6, 7, 8}

interseccion = conjunto1.intersection(conjunto2)
print(f"Números presentes en ambos conjuntos: {interseccion}")
