# Ejercicio 4: Verificar si un conjunto es subconjunto de otro
conjunto1 = {1, 2}
conjunto2 = {1, 2, 3, 4, 5}

es_subconjunto = conjunto1.issubset(conjunto2)
print(f"¿Es el primer conjunto un subconjunto del segundo? {es_subconjunto}")
