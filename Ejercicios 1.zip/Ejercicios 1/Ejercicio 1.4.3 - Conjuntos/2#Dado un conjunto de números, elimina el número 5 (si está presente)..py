# Ejercicio 2: Eliminar el número 5 de un conjunto
conjunto = {1, 2, 3, 4, 5, 6}

conjunto.discard(5)  # Elimina el número 5 si está presente
print(f"Conjunto después de eliminar el 5: {conjunto}")
