# Ejercicio 3: Unión de dos conjuntos
conjunto1 = {1, 2, 3}
conjunto2 = {3, 4, 5}

union = conjunto1.union(conjunto2)
print(f"Unión de los dos conjuntos: {union}")
