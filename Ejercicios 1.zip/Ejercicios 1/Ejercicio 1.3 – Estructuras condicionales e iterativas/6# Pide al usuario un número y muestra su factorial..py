# Pide al usuario un numero y muestra su factorial
import math

numero = int(input("Introduce un número para calcular su factorial: "))
factorial = math.factorial(numero)
print(f"La factorial de {numero} es {factorial}.")
