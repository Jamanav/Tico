4# Pide al usuario un número e imprime su tabla de multiplicar.
numero = int(input("Introduce un número para mostrar su tabla de multiplicar: "))
for i in range(1, 11):
    print(f"{numero} x {i} = {numero * i}")
