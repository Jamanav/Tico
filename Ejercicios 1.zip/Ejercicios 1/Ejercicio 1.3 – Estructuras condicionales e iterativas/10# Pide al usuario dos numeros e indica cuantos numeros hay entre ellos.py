# Pide al usuario dos numeros e indica cuantos numeros hay entre ellos 

num1 = int(input("Introduce el primer número: "))
num2 = int(input("Introduce el segundo número: "))

if num1 < num2:
    cantidad = num2 - num1 - 1
else:
    cantidad = num1 - num2 - 1

print(f"Hay {cantidad} números entre {num1} y {num2}.")
