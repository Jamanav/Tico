# Solicita al usuario dos números
num1 = int(input("Introduce el primer número: "))
num2 = int(input("Introduce el segundo número: "))

# Compara los números e imprime el resultado
if num1 > num2:
    print(f"{num1} es mayor que {num2}.")
elif num1 < num2:
    print(f"{num2} es mayor que {num1}.")
else:
    print("Los números son iguales.")
