#Solicita al usuario un numero y muestra si es primo o no 

numero = int(input("Introduce un número: "))
if numero > 1:
    for i in range(2, int(numero**0.5) + 1):
        if numero % i == 0:
            print(f"{numero} no es primo.")
            break
    else:
        print(f"{numero} es primo.")
else:
    print(f"{numero} no es primo.")
