# Solicita un numero al usuario y muestra si es o no multiplo de 5
numero = int(input("Introduce un número: "))
if numero % 5 == 0:
    print("El número es múltiplo de 5.")
else:
    print("El número no es múltiplo de 5.")
