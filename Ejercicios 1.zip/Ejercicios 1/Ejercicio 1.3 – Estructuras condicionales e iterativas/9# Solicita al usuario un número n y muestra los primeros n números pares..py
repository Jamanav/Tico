# Solicita al usuario un numero "x" y muestra los primeros "x" numeros pares 
x = int(input("Introduce un número: "))
print(f"Los primeros {x} números pares son:")
for i in range(x):
    print(i * 2)
