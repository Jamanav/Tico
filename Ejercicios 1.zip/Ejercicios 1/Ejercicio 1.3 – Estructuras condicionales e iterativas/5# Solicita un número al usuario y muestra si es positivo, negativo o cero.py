# Solicita un numero al usuario y muestra si es positivo , negativo o cero 
numero = float(input("Introduce un número: "))
if numero > 0:
    print("El número es positivo.")
elif numero < 0:
    print("El número es negativo.")
else:
    print("El número es cero.")
