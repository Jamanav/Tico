3# Usando un bucle, muestra los números del 1 al 10.

# Muestra los números del 1 al 10
for i in range(1, 11):
    print(i)