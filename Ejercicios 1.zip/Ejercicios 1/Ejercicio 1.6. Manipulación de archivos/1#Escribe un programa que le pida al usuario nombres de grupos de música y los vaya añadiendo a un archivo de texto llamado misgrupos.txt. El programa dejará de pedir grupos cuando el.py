

def guardar_grupos():
    with open('misgrupos.txt', 'a') as archivo:  # Abrimos el archivo en modo 'append'
        while True:
            grupo = input("Introduce un grupo de música (o escribe 'Salir' para terminar): ")
            if grupo.lower() == 'salir':
                break  # Salimos del bucle si el usuario escribe 'Salir'
            archivo.write(grupo + '\n')  # Escribimos el grupo en el archivo

if __name__ == "__main__":
    guardar_grupos()
    print("Grupos guardados en 'misgrupos.txt'.")
