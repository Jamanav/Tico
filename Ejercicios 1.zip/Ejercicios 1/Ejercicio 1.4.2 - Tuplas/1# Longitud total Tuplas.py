# Tupla de ciudades
ciudades = ('Cadiz', 'Malaga', 'Almeria', 'Sevilla', 'Huelva', 'Cordoba' , 'Jaén', 'Granada')

# Encuentra la posición del elemento 'Sevilla'
posicion_sevilla = ciudades.index('Sevilla')

# Calcula la longitud total de la tupla
longitud_tupla = len(ciudades)

# Muestra los resultados
print(f"La posición de 'Sevilla' es: {posicion_sevilla}")
print(f"La longitud total de la tupla es: {longitud_tupla}")
