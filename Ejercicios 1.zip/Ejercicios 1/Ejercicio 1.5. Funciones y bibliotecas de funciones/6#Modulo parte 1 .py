from modulojavier import sumar, restar, multiplicar

# Prueba de las funciones del módulo
if __name__ == "__main__":
    print(sumar(5, 3))
    print(restar(5, 3))
    print(multiplicar(5, 3))

