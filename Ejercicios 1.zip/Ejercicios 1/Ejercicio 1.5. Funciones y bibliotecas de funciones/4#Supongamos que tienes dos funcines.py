def suma(a, b):
    return a + b

def resta(a, b):
    return a - b

def operacion(a, b):
    return 2 * suma(a, b) - resta(a, b)

# Llamada a la función operacion y muestra del resultado
print(operacion(5, 3))
