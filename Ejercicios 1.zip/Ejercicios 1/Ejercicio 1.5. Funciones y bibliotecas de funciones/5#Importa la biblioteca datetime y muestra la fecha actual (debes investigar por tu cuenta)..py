from datetime import datetime

def fecha_actual():
    return datetime.now()

# Prueba de la función
if __name__ == "__main__":
    print(fecha_actual())
