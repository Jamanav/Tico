def potencia(base, exponente=2):
    return base ** exponente

# Prueba de la función
if __name__ == "__main__":
    print(potencia(3))  # Por defecto al cuadrado
    print(potencia(3, 3))  # Al cubo
