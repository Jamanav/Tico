import math

def raiz_cuadrada(numero):
    return math.sqrt(numero)

# Prueba de la función
if __name__ == "__main__":
    print(raiz_cuadrada(81))
