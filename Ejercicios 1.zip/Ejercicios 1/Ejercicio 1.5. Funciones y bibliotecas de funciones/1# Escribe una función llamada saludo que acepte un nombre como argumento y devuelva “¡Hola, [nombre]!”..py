def saludo(nombre):
    return "¡Hola, {}!".format(nombre)

# Prueba de la función
if __name__ == "__main__":
    print(saludo("Carlos"))  # Cambia "Carlos" por cualquier nombre que desees
