# Pide al usuario la longitud y el ancho de un rectángulo. Calcula y muestra su área.
longitud = float(input("Introduce la longitud del rectángulo: "))
ancho = float(input("Introduce el ancho del rectángulo: "))
area = longitud * ancho
print(f"El área del rectángulo es: {area}")
