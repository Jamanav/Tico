# Pide al usuario su edad y muestra cuántos años tendrá el próximo año.

edad = int(input("¿Cuántos años tienes? "))
print(f"El próximo año tendrás {edad + 1} años.")