# Solicita un precio y un descuento. Muestra el precio final tras aplicar el descuento.
precio = float(input("Introduce el precio: "))
descuento = float(input("Introduce el descuento (en porcentaje): "))
precio_final = precio - (precio * (descuento / 100))
print(f"El precio final es: {precio_final}")
