# Solicita al usuario su nombre y el nombre de su mejor amigo/a.
nombre = input("¿Cuál es tu nombre? ")
amigo = input("¿Cuál es el nombre de tu mejor amigo/a? ")
print(f"{nombre} y {amigo} son grandes amigos.")
