# Solicita el nombre de una persona y su color favorito.
nombre = input("¿Cuál es tu nombre? ")
color_favorito = input("¿Cuál es tu color favorito? ")
print(f"{nombre}, tu color favorito es {color_favorito}.")
