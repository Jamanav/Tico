# Solicita dos números al usuario y muestra su suma.
num1 = int(input("Introduce el primer número: "))
num2 = int(input("Introduce el segundo número: "))
suma = num1 + num2
print(f"La multiplicacion es: {suma}") 
