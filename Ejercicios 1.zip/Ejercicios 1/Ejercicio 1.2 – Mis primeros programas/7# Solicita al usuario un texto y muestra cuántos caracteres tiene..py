# Solicita al usuario un texto y muestra cuántos caracteres tiene.
texto = input("Introduce un texto: ")
print(f"El texto tiene {len(texto)} caracteres.")
