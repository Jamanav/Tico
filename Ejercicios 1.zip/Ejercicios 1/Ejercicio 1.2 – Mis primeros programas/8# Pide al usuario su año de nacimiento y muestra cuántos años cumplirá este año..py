# Pide al usuario su año de nacimiento y muestra cuántos años cumplirá este año.
ano_nacimiento = int(input("¿En qué año naciste? "))
ano_actual = 2023  # Cambia este valor al año actual si es necesario
edad = ano_actual - ano_nacimiento
print(f"Este año cumplirás {edad} años.")
