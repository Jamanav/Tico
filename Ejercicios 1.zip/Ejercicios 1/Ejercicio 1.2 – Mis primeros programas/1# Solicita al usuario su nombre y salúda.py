# Solicita al usuario su nombre y salúdale.
nombre = input("¿Cuál es tu nombre? ")
print(f"Hola, {nombre}!")
