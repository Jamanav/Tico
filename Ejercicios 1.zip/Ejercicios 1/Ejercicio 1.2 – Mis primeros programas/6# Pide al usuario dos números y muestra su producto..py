# Pide al usuario dos números y muestra su producto.
num1 = int(input("Introduce el primer número: "))
num2 = int(input("Introduce el segundo número: "))
producto = num1 * num2
print(f"El producto es: {producto}")
