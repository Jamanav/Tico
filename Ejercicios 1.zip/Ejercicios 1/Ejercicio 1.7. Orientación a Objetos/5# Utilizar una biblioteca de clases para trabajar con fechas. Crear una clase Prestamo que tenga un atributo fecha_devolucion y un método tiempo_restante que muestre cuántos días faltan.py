#extension_libro.py

from datetime import datetime, timedelta

class Libro:
    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas
    
    def info(self):
        return f"Título: {self.titulo}, Autor: {self.autor}, Páginas: {self.paginas}"

    def leer(self, paginas_a_leer):
        if paginas_a_leer > self.paginas:
            paginas_a_leer = self.paginas  # No leer más páginas de las que quedan
        self.paginas -= paginas_a_leer  # Reducir las páginas restantes
        return self.paginas  # Retornar el número de páginas que quedan


class Ebook(Libro):
    def __init__(self, titulo, autor, paginas, porcentaje_bateria):
        super().__init__(titulo, autor, paginas)  # Llama al constructor de Libro
        self.porcentaje_bateria = porcentaje_bateria

    def leer(self, paginas_a_leer):
        if paginas_a_leer > self.paginas:
            paginas_a_leer = self.paginas  # Ajustar a las páginas restantes
        super().leer(paginas_a_leer)  # Llamar al método leer de Libro
        # Reducir la batería
        self.porcentaje_bateria -= paginas_a_leer // 10  # 1% por cada 10 páginas leídas
        # Asegurarse de que la batería no sea menor que 0
        self.porcentaje_bateria = max(self.porcentaje_bateria, 0)
        return self.paginas, self.porcentaje_bateria  # Retornar páginas restantes y batería


class Biblioteca:
    def __init__(self):
        self.libros = []  # Lista para almacenar libros
        self.ebooks = []  # Lista para almacenar ebooks

    def agregar_libro(self, libro):
        self.libros.append(libro)  # Agregar un libro a la lista

    def agregar_ebook(self, ebook):
        self.ebooks.append(ebook)  # Agregar un ebook a la lista

    def mostrar_titulos(self):
        print("Libros disponibles:")
        for libro in self.libros:
            print(libro.info())
        print("Ebooks disponibles:")
        for ebook in self.ebooks:
            print(ebook.info())


class Prestamo:
    def __init__(self, libro, dias_prestamo):
        self.libro = libro
        self.fecha_devolucion = datetime.now() + timedelta(days=dias_prestamo)

    def tiempo_restante(self):
        dias_restantes = (self.fecha_devolucion - datetime.now()).days
        return max(dias_restantes, 0)  # Asegurarse de que no sea negativo

# Ejemplo de uso
if __name__ == "__main__":
    biblioteca = Biblioteca()
    
    libro1 = Libro("Cien años de soledad", "Gabriel García Márquez", 400)
    ebook1 = Ebook("El amor en los tiempos del cólera", "Gabriel García Márquez", 250, 100)

    biblioteca.agregar_libro(libro1)
    biblioteca.agregar_ebook(ebook1)

    biblioteca.mostrar_titulos()

    prestamo = Prestamo(libro1, 15)
    print(f"Días restantes para la devolución: {prestamo.tiempo_restante()} días")
