# libro , ebook.py

class Libro:
    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas
    
    def info(self):
        return f"Título: {self.titulo}, Autor: {self.autor}, Páginas: {self.paginas}"

    def leer(self, paginas_a_leer):
        if paginas_a_leer > self.paginas:
            paginas_a_leer = self.paginas  # No leer más páginas de las que quedan
        self.paginas -= paginas_a_leer  # Reducir las páginas restantes
        return self.paginas  # Retornar el número de páginas que quedan


class Ebook(Libro):
    def __init__(self, titulo, autor, paginas, porcentaje_bateria):
        super().__init__(titulo, autor, paginas)  # Llama al constructor de Libro
        self.porcentaje_bateria = porcentaje_bateria

    def leer(self, paginas_a_leer):
        if paginas_a_leer > self.paginas:
            paginas_a_leer = self.paginas  # Ajustar a las páginas restantes
        super().leer(paginas_a_leer)  # Llamar al método leer de Libro
        # Reducir la batería
        self.porcentaje_bateria -= paginas_a_leer // 10  # 1% por cada 10 páginas leídas
        # Asegurarse de que la batería no sea menor que 0
        self.porcentaje_bateria = max(self.porcentaje_bateria, 0)
        return self.paginas, self.porcentaje_bateria  # Retornar páginas restantes y batería

# Ejemplo de uso
if __name__ == "__main__":
    ebook1 = Ebook("El amor en los tiempos del cólera", "Gabriel García Márquez", 250, 100)
    print(ebook1.info())
    
    # Leer algunas páginas
    paginas_leidas = 25
    paginas_restantes, bateria_restante = ebook1.leer(paginas_leidas)
    print(f"Páginas restantes después de leer {paginas_leidas}: {paginas_restantes}")
    print(f"Porcentaje de batería restante: {bateria_restante}%")
