#Creacion de libro 

class Libro:
    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas
    
    def info(self):
        return f"Título: {self.titulo}, Autor: {self.autor}, Páginas: {self.paginas}"

    def leer(self, paginas_a_leer):
        if paginas_a_leer > self.paginas:
            paginas_a_leer = self.paginas  # No leer más páginas de las que quedan
        self.paginas -= paginas_a_leer  # Reducir las páginas restantes
        return self.paginas  # Retornar el número de páginas que quedan

# Ejemplo de uso
if __name__ == "__main__":
    libro1 = Libro("Cien años de soledad", "Gabriel García Márquez", 400)
    print(libro1.info())
    
    # Leer algunas páginas
    paginas_leidas = 50
    libro1.leer(paginas_leidas)
    print(f"Páginas restantes después de leer {paginas_leidas}: {libro1.paginas}")
