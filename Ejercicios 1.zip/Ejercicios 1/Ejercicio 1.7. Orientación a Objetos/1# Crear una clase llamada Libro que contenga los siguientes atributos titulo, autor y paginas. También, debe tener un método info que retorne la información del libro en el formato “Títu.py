#Creacion de libro

class Libro:
    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas
    
    def info(self):
        return f"Título: {self.titulo}, Autor: {self.autor}, Páginas: {self.paginas}"

# Ejemplo de uso
if __name__ == "__main__":
    libro1 = Libro("Cien años de soledad", "Gabriel García Márquez", 400)
    print(libro1.info())
